"""Q-PSC, quantum precision shrinkage clustering: clustering on the certified graph of exact quantum states (Methods).

Every cell is joined to its 15 nearest quantum states, found exactly and certified by Theorem 4 (sckqe2.qstate.state_knn).
The edge between cells i and j is weighted by their state fidelity F_ij = exp(-D_ij), D = -log F, and the graph is made
symmetric by the larger of the two directed weights. Leiden (seed 0) is bisected to round(1.5 k) clusters on this graph
(Python rounding: halves go to the even integer, as in the runs of the paper), and the pair of clusters with the largest
normalized connectivity C_ab / sqrt(v_a v_b) is merged repeatedly until k clusters remain (sckqe2.psc.merge_to_k).
No step draws a random number.

KQE-2 applies Q-PSC whenever the gene-set rule selects the whole transcriptome; on atlases for which it selects 5,000 HVGs,
Leiden at k on the 15-nearest-neighbor graph of the quantum features is used directly (KQE2(qpsc="auto")).
"""
import numpy as np
import scipy.sparse as sp
from .cluster import leiden_at_k
from .psc import merge_to_k

FACTOR = 1.5


def quantum_graph(I, D):
    """Weighted adjacency of the certified nearest-state graph: weight exp(-D) (the fidelity), self loops removed,
    symmetrized by the maximum of the two directions. I, D: (cells, k) neighbor indices and -log F distances."""
    I = np.asarray(I); n = I.shape[0]
    rows = np.repeat(np.arange(n), I.shape[1]); cols = I.ravel(); w = np.exp(-np.asarray(D, np.float64).ravel())
    keep = rows != cols
    G = sp.csr_matrix((w[keep], (rows[keep], cols[keep])), shape=(n, n))
    return G.maximum(G.T).tocsr()


def qpsc_from_graph(G, k, factor=FACTOR, seed=0):
    """Leiden at round(factor * k) clusters on the quantum graph G, then merge to k. Returns (labels, resolution)."""
    pre, res = leiden_at_k(G, int(round(factor * k)), seed=seed, hi=6.0)
    return merge_to_k(pre, G, k), res


def qpsc(E, k, s=0.19, n_neighbors=15, factor=FACTOR, seed=0, return_graph=False, **knn_kw):
    """Q-PSC from whitened scores E (cells x 132): certified exact nearest states, fidelity graph, Leiden and merge.
    Returns (labels, resolution) or, with return_graph=True, (labels, resolution, G, I, D, certified)."""
    from .qstate import state_knn
    I, D, cert = state_knn(E, s=s, k=n_neighbors, **knn_kw)
    G = quantum_graph(I, D)
    labels, res = qpsc_from_graph(G, k, factor=factor, seed=seed)
    return (labels, res, G, I, D, cert) if return_graph else (labels, res)
