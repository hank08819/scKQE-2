"""scKQE-2 tutorial script: every code block of docs/tutorial.md, run in order on one atlas.
Usage: python tutorial.py atlas.h5ad [label column] [donor column]"""
import sys, time
import numpy as np
import anndata as ad
import scanpy as sc
import sckqe2
from sklearn.metrics import adjusted_mutual_info_score, adjusted_rand_score

path = sys.argv[1]; label = sys.argv[2] if len(sys.argv) > 2 else "cell_type"; donor = sys.argv[3] if len(sys.argv) > 3 else None

# 1. Load raw counts; keep annotated cells and types with at least 10 cells
adata = ad.read_h5ad(path)
y = adata.obs[label].astype(str)
keep = ~y.isin(["unknown", "nan"])
counts = y[keep].value_counts()
keep &= y.isin(counts.index[counts >= 10])
adata = adata[keep.values].copy()
k = adata.obs[label].nunique()
print(f"[1] {adata.n_obs} cells, {adata.n_vars} genes, {k} annotated types")

# 2. Choose the gene set with the locked, label-free rule
X = adata.raw.X if adata.raw is not None else adata.X
gene_set, delta, h_pa, n_signal = sckqe2.choose_gene_set(X, k)
print(f"[2] Delta = {delta:.2f} (h_PA = {h_pa:.2f}, {n_signal} signal directions) -> gene set: {gene_set}")

# 3. Cluster with scKQE-2
t0 = time.time()
model = sckqe2.kqe2(adata, n_clusters=k, gene_set=gene_set)
print(f"[3] {adata.obs['kqe2'].nunique()} clusters in {time.time() - t0:.0f} s; features {adata.obsm['X_kqe2'].shape}")

# 4. Compare with the annotation (labels are used only here and to set k)
print(f"[4] AMI with '{label}': {adjusted_mutual_info_score(adata.obs[label], adata.obs['kqe2']):.4f}")

# 5. Check reproducibility: a second run gives bit-identical features and the same clusters
first_features, first_clusters = adata.obsm["X_kqe2"].copy(), adata.obs["kqe2"].values.copy()
sckqe2.kqe2(adata, n_clusters=k, gene_set=gene_set)
print(f"[5] features identical: {np.array_equal(first_features, adata.obsm['X_kqe2'])}; "
      f"clusters identical: {np.array_equal(first_clusters, adata.obs['kqe2'].values)}")

# 6. Downstream analysis with scanpy: neighbors and UMAP on the quantum features, markers per cluster
sc.pp.neighbors(adata, use_rep="X_kqe2", n_neighbors=15, random_state=0)
sc.tl.umap(adata, random_state=0)
adata.layers["counts"] = (adata.raw.X if adata.raw is not None else adata.X).copy()
lognorm = adata.copy(); lognorm.X = lognorm.layers["counts"].copy()
if "feature_name" in lognorm.var.columns:                       # show gene symbols instead of Ensembl IDs
    lognorm.var_names = lognorm.var["feature_name"].astype(str).values; lognorm.var_names_make_unique()
sc.pp.normalize_total(lognorm, target_sum=1e4); sc.pp.log1p(lognorm)
lognorm.raw = None                                               # rank on the gene-symbol matrix, not on adata.raw
sc.tl.rank_genes_groups(lognorm, "kqe2", method="wilcoxon", n_genes=5)
top = sc.get.rank_genes_groups_df(lognorm, group=None).groupby("group").head(3)
print("[6] top markers of the first three clusters:")
for g, d in list(top.groupby("group"))[:3]:
    print(f"    cluster {g}: {', '.join(map(str, d['names']))}")

# 7. Optional: deterministic donor correction (quantum alignment)
if donor:
    m2 = sckqe2.kqe2(adata, n_clusters=k, gene_set=gene_set, donor_key=donor, key_added="kqe2_aligned")
    print(f"[7] aligned AMI: {adjusted_mutual_info_score(adata.obs[label], adata.obs['kqe2_aligned']):.4f}")
